//
//  CommunicateNavigationViewController.h
//  Liankeji
//
//  Created by 李自豪 on 16/12/15.
//  Copyright © 2016年 haichuanhuiwulianxinxi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommunicateNavigationViewController : UINavigationController

@end
