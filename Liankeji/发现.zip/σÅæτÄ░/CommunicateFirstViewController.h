//
//  CommunicateFirstViewController.h
//  Liankeji
//
//  Created by 李自豪 on 16/12/15.
//  Copyright © 2016年 haichuanhuiwulianxinxi. All rights reserved.
//发现首页

#import <UIKit/UIKit.h>
#import "BasicViewControllerOfAllMainPage.h"

@interface CommunicateFirstViewController : BasicViewControllerOfAllMainPage

@end
