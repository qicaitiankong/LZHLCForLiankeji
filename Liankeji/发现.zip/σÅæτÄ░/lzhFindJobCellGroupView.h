//
//  lzhFindJobCellGroupView.h
//  suipianTest
//
//  Created by mac on 2017/2/22.
//  Copyright © 2017年 mac. All rights reserved.
//适配完成

#import <UIKit/UIKit.h>
#import "lzhFindJobCellSmallView.h"

@interface lzhFindJobCellGroupView : UIView
//定位label
@property (strong,nonatomic)UILabel *firstLabel;
//学历label
@property (strong,nonatomic)UILabel *secondLabel;
//经验label
@property (strong,nonatomic)UILabel *thirdLabel;

@end
